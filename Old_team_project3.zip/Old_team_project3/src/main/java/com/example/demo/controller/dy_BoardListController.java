package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;
import java.util.Date;

@Controller
@RequestMapping("/dy_html") //URL의 기본 경로
public class dy_BoardListController {

    @GetMapping("/list") // "/dy_html/list" 요청 처리
    public String list(Model model) {
        
        // 예제 가짜 데이터(TEST시험용)
        List<Map<String, Object>> boardlist = List.of(
        Map.of("bnum", 1, "title", "공지사항 1", "ename", "관리자", "postdate", new Date(), "visitcount", 15),
        Map.of("bnum", 2, "title", "공지사항 2", "ename", "운영자", "postdate", new Date(), "visitcount", 30)
        );

        // totalPages 값 설정
        int totalPages = 5;  // 총 페이지 수 예제
        model.addAttribute("boardlist", boardlist);
        model.addAttribute("currentPage", 1); // 현재 페이지 예제
        model.addAttribute("totalPages", totalPages);


        // "dy_html/list.html" 파일 반환
        return "dy_html/list";
    }
}