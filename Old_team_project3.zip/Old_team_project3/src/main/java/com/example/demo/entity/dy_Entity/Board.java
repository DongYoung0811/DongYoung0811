package com.example.demo.entity.dy_Entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity // JPA 엔티티로 설정
@Table(name = "board") // 데이터베이스 테이블 이름과 매핑
public class Board {

  @Id // 기본 키 설정
  @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto Increment
  private Long bnum; // 번호 (Primary Key)
  private String title; // 제목
  private String ename; // 작성자
  private String content; // 내용
  private LocalDateTime postdate; // 작성일
  private int visitcount; // 조회수

  // Getter and Setter for bnum
    public Long getBnum() {
    return bnum;
    }

    public void setBnum(Long bnum) {
        this.bnum = bnum;
    }

    // Getter and Setter for title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Getter and Setter for ename
    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    // Getter and Setter for content
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    // Getter and Setter for postdate
    public LocalDateTime getPostdate() {
        return postdate;
    }

    public void setPostdate(LocalDateTime postdate) {
        this.postdate = postdate;
    }

    // Getter and Setter for visitcount
    public int getVisitcount() {
        return visitcount;
    }

    public void setVisitcount(int visitcount) {
        this.visitcount = visitcount;
    }

}