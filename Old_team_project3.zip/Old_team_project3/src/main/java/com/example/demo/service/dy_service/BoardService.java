package com.example.demo.service.dy_service;

import com.example.demo.entity.dy_Entity.*;
import com.example.demo.repository.dy_repository.BoardRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BoardService {
  
  private final BoardRepository boardRepository;
  
  public BoardService(BoardRepository boardRepository) {
    this.boardRepository = boardRepository;
  }
  
  // 게시글 목록 조회
  public List<Board> getBoardList() {
    return boardRepository.findAll();
  }
  
  // 게시글 상세 조회
  public Board getBoardDetail(Long bnum) {
    return boardRepository.findById(bnum).orElse(null);
  }
  
  // 게시글 등록
  public Board insertBoard(Board board) {
    return boardRepository.save(board);
  }
  
  // 게시글 수정
  public Board updateBoard(Board board) {
    return boardRepository.save(board);
  }
  
  // 게시글 삭제
  public void deleteBoard(Long bnum) {
    boardRepository.deleteById(bnum);
  }
}
