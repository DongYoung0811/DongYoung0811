package com.example.demo.repository.dy_repository;

import com.example.demo.entity.dy_Entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // Repository 계층임을 명시
public interface BoardRepository extends JpaRepository<Board, Long> {
  // 기본 CRUD 메서드는 JpaRepository가 제공
  // 필요 시 사용자 정의 메서드를 추가 가능
} 